package entites;

public class Classement {

}
